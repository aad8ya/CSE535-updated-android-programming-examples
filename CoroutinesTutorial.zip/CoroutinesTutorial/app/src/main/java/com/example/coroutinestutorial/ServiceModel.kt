package com.example.coroutinestutorial

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class ServiceViewModel : ViewModel() {
    private val _serviceStatus = MutableStateFlow("Service Idle")
    val serviceStatus = _serviceStatus.asStateFlow()

    fun runMockService() {
        viewModelScope.launch {
            _serviceStatus.value = "Service Started..."

            for (i in 1..10) {
                delay(1000)
                _serviceStatus.value = "Processing Step: $i"
            }

            _serviceStatus.value = "Service Completed!"
        }
    }
}